# Code of the figures of the notes *PAC-Bayesian Learning*

Guillaume Metzler -- Master MALIA, Ensemble Methods, Université Lumière Lyon 2.

Contents of the archive:

* `poly/make_figures.py`: one function `fig_xxx()` per Python figure (matplotlib);
* `poly/figures/`, `poly/tables/`: the figures and small tables it produces;
* `poly/tikz/`: one file per TikZ figure, `standalone.tex` and `build_tikz.sh`;
* `poly/list_figures.py`: rebuilds the list of figures below from the notes;
* `common/pbtools.py`: the PAC-Bayes module of the course (bounds, forests with out-of-bag sets);
* `common/polystyle.sty`, `common/usercommands.tex`: the style of the notes;
* `common/bibliography.bib`: the bibliography, sorted by citation key (`merge_bib.py`).

How to use:

* Python figures (from `poly/`): `python make_figures.py` regenerates all of them in `figures/`;
  `python make_figures.py fig_condorcet` regenerates a single one. The script needs
  `numpy`, `scipy`, `matplotlib`, `scikit-learn` and the course module `pbtools.py`.
* TikZ figures (from `poly/`): the files of `tikz/` are included in the notes with `\input{tikz/name}`;
  `sh tikz/build_tikz.sh` compiles each of them alone in `tikz/pdf/` (it needs the style
  files `polystyle.sty` and `usercommands.tex` of `common/`).

| Figure | Type | Source |
|---|---|---|
| 1 | TikZ | `tikz/roadmap.tex` |
| 2 | Python | `make_figures.py: fig_averaging_variance` |
| 3 | Python | `make_figures.py: fig_vote_correlation` |
| 4 | TikZ | `tikz/course_bridge.tex` |
| 5 | Python | `make_figures.py: fig_forest_growth` |
| 6 | Python | `make_figures.py: fig_adaboost` |
| 7 | TikZ | `tikz/ensembles_as_q.tex` |
| 8 | Python | `make_figures.py: fig_gibbs_vs_mv` |
| 9 | TikZ | `tikz/principle.tex` |
| 10 | TikZ | `tikz/timeline.tex` |
| 11 | TikZ | `tikz/markov.tex` |
| 12 | Python | `make_figures.py: fig_kl_inverse` |
| 13 | Python | `make_figures.py: fig_kl_pinsker` |
| 14 | Python | `make_figures.py: fig_concentration` |
| 15 | Python | `make_figures.py: fig_kl_examples` |
| 16 | Python | `make_figures.py: fig_change_of_measure` |
| 17 | Python | `make_figures.py: fig_occam` |
| 18 | Python | `make_figures.py: fig_uniformity` |
| 19 | TikZ | `tikz/proof_steps.tex` |
| 20 | Python | `make_figures.py: fig_anytime` |
| 21 | Python | `make_figures.py: fig_bound_anatomy` |
| 22 | Python | `make_figures.py: fig_seeger_landscape` |
| 23 | Python | `make_figures.py: fig_bounds_comparison` |
| 24 | Python | `make_figures.py: fig_prior_posterior` |
| 25 | Python | `make_figures.py: fig_temperature` |
| 26 | Python | `make_figures.py: fig_prior_choice` |
| 27 | TikZ | `tikz/recursive_pb.tex` |
| 28 | Python | `make_figures.py: fig_ddprior` |
| 29 | Python | `make_figures.py: fig_montecarlo` |
| 30 | TikZ | `tikz/wq_line.tex` |
| 31 | Python | `make_figures.py: fig_wq_distribution` |
| 32 | Python | `make_figures.py: fig_wq_scenarios` |
| 33 | Python | `make_figures.py: fig_condorcet` |
| 34 | TikZ | `tikz/tandem_table.tex` |
| 35 | Python | `make_figures.py: fig_cbound_landscape` |
| 36 | Python | `make_figures.py: fig_bound_regions` |
| 37 | Python | `make_figures.py: fig_cctnd` |
| 38 | Python | `make_figures.py: fig_split_kl` |
| 39 | Python | `make_figures.py: fig_mv_bounds_diversity` |
| 40 | Python | `make_figures.py: fig_selfbounding_selection` |
| 41 | TikZ | `tikz/data_usage.tex` |
| 42 | Python | `make_figures.py: fig_selfbounding_vs_holdout` |
| 43 | TikZ | `tikz/sb_pipeline.tex` |
| 44 | Python | `make_figures.py: fig_selfbounding_dynamics` |
| 45 | TikZ | `tikz/oob_sets.tex` |
| 46 | Python | `make_figures.py: fig_fo_iterations_and_weights` |
| 47 | Python | `make_figures.py: fig_rf_optimisation` |
| 48 | Python | `make_figures.py: fig_probit_loss` |
| 49 | Python | `make_figures.py: fig_linear_gaussian` |
| 50 | Python | `make_figures.py: fig_pbgd` |
| 51 | Python | `make_figures.py: fig_rff` |
| 52 | TikZ | `tikz/research_map.tex` |
