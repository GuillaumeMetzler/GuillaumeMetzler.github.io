"""Merge G. Metzler's bibliography with the PAC-Bayes references and sort by citation key."""
import re, sys
def parse(f):
    t = open(f, encoding='utf-8', errors='replace').read()
    out = {}
    for p in re.split(r'(?m)^(?=\s*@)', t):
        m = re.match(r'\s*@(\w+)\s*\{\s*([^,\s]+)\s*,', p)
        if m:
            e = p.strip()
            # drop trailing comment lines after the closing brace
            e = e[:e.rfind('}') + 1]
            out[m.group(2)] = e
    return out
merged = {}
for f in ['user_bibliography_original.bib', 'pacbayes.bib', 'new_refs_v6.bib', 'new_refs_v8.bib']:   # later files win
    merged.update(parse(f))
keys = sorted(merged, key=lambda k: k.lower())
with open('bibliography.bib', 'w', encoding='utf-8') as g:
    g.write('%% bibliography.bib -- G. Metzler, merged bibliography (template bibliography\n'
            '%% + PAC-Bayes references), sorted alphabetically by citation key.\n\n')
    for k in keys:
        g.write(merged[k] + '\n\n')
print(len(keys), 'entries')
