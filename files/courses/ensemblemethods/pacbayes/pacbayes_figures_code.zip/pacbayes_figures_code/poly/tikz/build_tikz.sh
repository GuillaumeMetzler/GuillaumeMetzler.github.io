#!/bin/sh
# Compile every TikZ figure of the notes into a standalone PDF (folder pdf/).
cd "$(dirname "$0")"
mkdir -p pdf
for f in *.tex; do
  n="${f%.tex}"
  [ "$n" = standalone ] && continue
  pdflatex -interaction=nonstopmode -output-directory=pdf -jobname="$n" "\def\figname{$n}\input{standalone}" >/dev/null 2>&1 \
    && echo "ok   $n" || echo "FAIL $n (see pdf/$n.log)"
done
rm -f pdf/*.aux pdf/*.out
